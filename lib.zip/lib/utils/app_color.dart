import 'package:flutter/material.dart';

class AppColors{
  AppColors._();
  static const Color appColors=Color(0xffd2463f);
  static const Color white=Colors.white;
}