class AppImages{
  AppImages._();
  static const AppLogo="assets/images/AppLogo.png";

}